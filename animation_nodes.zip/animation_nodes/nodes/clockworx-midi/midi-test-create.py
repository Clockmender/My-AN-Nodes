import bpy
import bmesh
from mathutils import Vector
from bpy.props import *
from ... base_types import AnimationNode
from . midi_functions import getIndex

class testCreate(bpy.types.Node, AnimationNode):
    bl_idname = "an_testCreate"
    bl_label = "Test Create"

    offset  : IntProperty(name="Offset",min=0)
    len     : IntProperty(name="Length",min=1)
    xLoc    : FloatProperty(name="X Loc")
    message : StringProperty()
    skipF   : IntProperty(name="Skip at Start",min=0)

    def draw(self,layout):
        layout.prop(self,"xLoc")
        layout.prop(self,"offset")
        layout.prop(self,"len")
        layout.prop(self,"skipF")
        if self.message is not "":
            layout.label(text = self.message, icon = "INFO")
        col = layout.column()
        self.invokeFunction(col, "testCreate", icon = "ADD",
            text = "Create Test in AC")

    def create(self):
        self.newInput("an_GenericSocket","Event Dict","eventD")
        self.newOutput("an_TextListSocket","Keys","keys")
        self.newOutput("an_GenericListSocket","Out List","outL")

    def testCreate(self):
        loc = (-self.xLoc,self.offset/10,0.0)
        bpy.ops.mesh.primitive_plane_add(size=0.1,location=loc)
        obj = bpy.context.view_layer.objects.active
        obj.name = "note_"+str(self.len)
        verts = obj.data.vertices
        verts[0].co = Vector((0.0,0.0,0.0))
        verts[1].co = Vector((-self.len/10,0.0,0.0))
        verts[2].co = Vector((0.0,0.1,0.0))
        verts[3].co = Vector((-self.len/10,0.1,0.0))
        obj.select_set(state=False)

    def execute(self,eventD):
        outList = []
        if eventD is not None:
            for r in eventD.keys():
                self.message = str(len(eventD[r]))
                for i in range(0,len(eventD[r])):
                    if eventD[r][i][1] == 1 and eventD[r][i+1][1] == 1:
                        # Start Location (X Loc)
                        startT = round((eventD[r][i][0]-self.skipF) / 10,4)
                        # Note Length
                        durT = round(((eventD[r][i+1][0]-self.skipF) - (eventD[r][i][0]-self.skipF)) / 10,4)
                        # Note Index (Y Loc)
                        offSet = getIndex(r) / 10
                        outList.append([offSet,startT,durT])
        return eventD.keys(), outList
