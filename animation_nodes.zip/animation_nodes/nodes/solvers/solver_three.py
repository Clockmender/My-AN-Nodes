import bpy
import bmesh
from bpy.props import *
from ... base_types import AnimationNode
from ... events import propertyChanged
from mathutils import Vector, Euler, Matrix

class an_SolverThreeNode(bpy.types.Node, AnimationNode):
    bl_idname = "an_SolverThreeNode"
    bl_label = "SOLVER:- Propagator"
    bl_width_default = 180

    useRan:  BoolProperty(name='Use Stop F',default = True,update=propertyChanged)
    startF:  IntProperty(name="Start Frame",default=2,min=2,update=propertyChanged)
    stopF:   IntProperty(name="Stop Frame",default=3,min=3,update=propertyChanged)
    resetF:  IntProperty(name="Reset Frame",default=10,min=3,update=propertyChanged)
    matSlot: IntProperty(name="Last Material Slot")
    message: StringProperty()
    variables = {}

    def draw(self,layout):
        layout.prop(self,"startF")
        layout.prop(self,"stopF")
        layout.prop(self,"resetF")
        layout.prop(self,"useRan")
        if (self.message is not ""):
            layout.label(text = self.message, icon = "ERROR")

    def create(self):
        self.newInput("an_ObjectSocket","Input Mesh","inpM")
        self.newInput("an_ObjectSocket","Output Mesh","outM")
        self.newInput("an_BooleanSocket","Process","process")
        self.newInput("an_MatrixSocket","Delta Matrix","iMatrix")
        self.newInput("an_MatrixSocket","Start Matrix","zMatrix")
        self.newOutput("an_ObjectSocket","Output Object","outObj")
        self.newOutput("an_MatrixSocket","Output Matrix","oMatrix")       #new

    def execute(self,inpM,outM,process,iMatrix,zMatrix):
        self.use_custom_color = True
        self.useNetworkColor = False
        self.color = (0.4,0.8,0.8)
        if self.resetF <= self.stopF or self.stopF <= self.startF:
            self.message = 'Possible Problems with Inputs'
            return None, None
        elif inpM is not None and outM is not None:
            if len(inpM.material_slots) < 1:
                self.message = 'No Materials on Input Object'
                return None, None
            if '.' in self.name:
                indX = '_'+self.name.split('.')[1]
            else:
                indX = '_000'
            if 'Matrix'+indX in self.variables:              # Try this
                sMatrix = self.variables['Matrix'+indX]
            else:
                sMatrix = outM.matrix_world

            frameC = bpy.context.scene.frame_current
            self.message = ''
            if self.useRan:
                rangeO = range(self.startF,self.stopF+1)
            else:
                rangeO = range(self.startF,bpy.context.scene.frame_end)
            self.variables[inpM.name] = inpM.material_slots[0].material
            self.message = ""
            if frameC < self.startF:
                dataN=inpM.data.copy()
                outM.data = dataN
                self.matSlot = 0
                self.variables['Matrix'+indX] = zMatrix
            elif frameC == self.resetF and self.useRan:
                dataN=inpM.data.copy()
                outM.data = dataN
                self.variables['Matrix'+indX] = zMatrix
            elif frameC in rangeO and process:
                #Check Materials
                mBool = False
                for s in outM.material_slots:
                    if s.material == self.variables[inpM.name]:
                        mBool = True
                if not mBool:
                    # New Material in next slot
                    self.matSlot = self.matSlot + 1
                    outM.data.materials.append(self.variables[inpM.name])
                oMatrix = sMatrix @ iMatrix
                dataI = inpM.data.copy()
                dataO = outM.data
                bm = bmesh.new()
                bm.from_mesh(dataI)
                bm.transform(oMatrix)
                # Change Material if input material changes.
                for p in bm.faces:
                    p.material_index = self.matSlot
                bm.from_mesh(dataO)
                bm.to_mesh(dataO)
                bm.free()
                self.variables['Matrix'+indX] = oMatrix
                return outM, oMatrix

            return outM, sMatrix
        else:
            return None, None
