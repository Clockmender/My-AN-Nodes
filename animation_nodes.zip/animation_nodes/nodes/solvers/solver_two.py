import bpy
from bpy.props import *
from ... base_types import AnimationNode
from ... events import propertyChanged
from mathutils import Vector

storedLocs = {}

class an_SolverTwoNode(bpy.types.Node, AnimationNode):
    bl_idname = "an_SolverTwoNode"
    bl_label = "SOLVER:- Chaser"
    bl_width_default = 180

    oldLoc:   FloatVectorProperty(name="Location",subtype="XYZ",update=propertyChanged)
    objLoc:   FloatVectorProperty(name="Location",subtype="XYZ",update=propertyChanged)
    chaLoc:   FloatVectorProperty(name="Location",subtype="XYZ",update=propertyChanged)

    def create(self):
        self.newInput("an_ObjectSocket", "Lead", "object")
        self.newInput("an_ObjectSocket", "Chaser", "chaser")
        self.newInput("an_VectorSocket", "Delta", "delta")
        self.newInput("an_BooleanSocket","Process","procLoc")
        self.newOutput("an_VectorSocket","Output Vector","outVec")

    def execute(self,object,chaser,delta,procLoc):
        self.use_custom_color = True
        self.useNetworkColor = False
        self.color = (0.4,0.8,0.8)
        if object is None or chaser is None:
            return
        frameC = bpy.context.scene.frame_current
        if frameC < bpy.context.scene.frame_start:
            self.objLoc = object.location
            self.chaLoc = chaser.location
            outVec = object.location
        elif frameC == bpy.context.scene.frame_start:
            object.location = self.objLoc
            chaser.location = self.chaLoc
            outVec = object.location
            storedLocs[object.name] = object.location
        else:
            if procLoc:
                self.oldLoc = storedLocs[object.name]
                object.location = object.location + delta
                chaser.location = self.oldLoc
                storedLocs[object.name] = object.location
                outVec = object.location
            else:
                outVec = Vector((0,0,0))
        return outVec
