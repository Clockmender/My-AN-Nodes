import bpy
from bpy.props import *
from ... base_types import AnimationNode
from ... events import propertyChanged
from mathutils import Vector
from math import sqrt
import random

storedLocs = {}

class an_SolverOneNode(bpy.types.Node, AnimationNode):
    bl_idname = "an_SolverOneNode"
    bl_label = "SOLVER:- Random Mover"
    bl_width_default = 180

    oldLoc:   FloatVectorProperty(name="Location",subtype="XYZ",update=propertyChanged)
    dist:     FloatProperty(name="Shrink Distance",default=0,min=0,update=propertyChanged)
    facDist:  FloatProperty(name="Factor Distance",default=0.1,min=0.001,update=propertyChanged)
    ranFac:   FloatProperty(name="Rand Factor",default=5,min=1,update=propertyChanged)
    infStart: IntProperty(name="Start Influence",default=10,min=10,update=propertyChanged)
    infStop:  IntProperty(name="Full Influence",default=15,min=15,update=propertyChanged)
    infFly:   IntProperty(name="Free Influence",default=30,min=30,update=propertyChanged)

    def draw(self,layout):
        layout.prop(self,"infStart")
        layout.prop(self,"infStop")
        layout.prop(self,"infFly")
        layout.prop(self,"ranFac")
        layout.prop(self,"dist")
        layout.prop(self,"facDist")

    def create(self):
        self.newInput("an_ObjectListSocket", "Objects", "objects")
        self.newInput("an_BooleanSocket","Process","procLoc")
        self.newOutput("an_VectorListSocket","Output Vectors","outNumb")

    def execute(self,objects,procLoc):
        self.use_custom_color = True
        self.useNetworkColor = False
        self.color = (0.4,0.8,0.8)
        outNumb = []
        frameC = bpy.context.scene.frame_current

        for object in objects:
            if 'Shrinkwrap' not in object.constraints:
                return None
            object.constraints['Shrinkwrap'].distance = self.dist
            rand = random.random()
            fac = 1 if rand < 0.5 else -1
            xrand = random.random() / self.ranFac * fac
            yrand = random.random() / self.ranFac * fac
            zrand = random.random() / self.ranFac * fac
            delta = Vector((xrand,yrand,zrand))
            if frameC < self.infStart:
                object.constraints['Shrinkwrap'].influence = 0
            elif frameC in range(self.infStart,self.infStop):
                object.constraints['Shrinkwrap'].influence = 1/(self.infStop-frameC)
            elif frameC in range(self.infFly-10,self.infFly):
                object.constraints["Shrinkwrap"].influence = 0 + ((self.infFly-frameC)/10)

            if frameC < 4:
                object.location = Vector((xrand,yrand,zrand))
            if procLoc:
                self.oldLoc = storedLocs[object.name] if storedLocs.get(object.name) else Vector((xrand,yrand,zrand))
                object.location = object.location + delta

                xdist = self.oldLoc[0]-object.location[0]
                ydist = self.oldLoc[1]-object.location[1]
                zdist = self.oldLoc[2]-object.location[2]
                dist = sqrt(xdist**2+ydist**2+zdist**2)
                if dist > self.facDist and object.constraints['Shrinkwrap'].influence == 1:
                    object.location = self.oldLoc + Vector((self.dist,self.dist,self.dist))
                storedLocs[object.name] = object.matrix_world.decompose()[0]
                outNumb.append(Vector((xrand,yrand,zrand)))
            else:
                outNumb.append(Vector((0,0,0)))

        return outNumb
